# Convolutional Neural Networks: Application

Welcome to Course 4's second assignment! In this notebook, you will:

- Create a mood classifer using the TF Keras Sequential API
- Build a ConvNet to identify sign language digits using the TF Keras Functional API

**After this assignment you will be able to:**

- Build and train a ConvNet in TensorFlow for a __binary__ classification problem
- Build and train a ConvNet in TensorFlow for a __multiclass__ classification problem
- Explain different use cases for the Sequential and Functional APIs

To complete this assignment, you should already be familiar with TensorFlow. If you are not, please refer back to the **TensorFlow Tutorial** of the third week of Course 2 ("**Improving deep neural networks**").

## Important Note on Submission to the AutoGrader

Before submitting your assignment to the AutoGrader, please make sure you are not doing the following:

1. You have not added any _extra_ `print` statement(s) in the assignment.
2. You have not added any _extra_ code cell(s) in the assignment.
3. You have not changed any of the function parameters.
4. You are not using any global variables inside your graded exercises. Unless specifically instructed to do so, please refrain from it and use the local variables instead.
5. You are not changing the assignment code where it is not required, like creating _extra_ variables.

If you do any of the following, you will get something like, `Grader Error: Grader feedback not found` (or similarly unexpected) error upon submitting your assignment. Before asking for help/debugging the errors in your assignment, check for these first. If this is the case, and you don't remember the changes you have made, you can get a fresh copy of the assignment by following these [instructions](https://www.coursera.org/learn/convolutional-neural-networks/supplement/DS4yP/h-ow-to-refresh-your-workspace).

## Table of Contents

- [1 - Packages](#1)
    - [1.1 - Load the Data and Split the Data into Train/Test Sets](#1-1)
- [2 - Layers in TF Keras](#2)
- [3 - The Sequential API](#3)
    - [3.1 - Create the Sequential Model](#3-1)
        - [Exercise 1 - happyModel](#ex-1)
    - [3.2 - Train and Evaluate the Model](#3-2)
- [4 - The Functional API](#4)
    - [4.1 - Load the SIGNS Dataset](#4-1)
    - [4.2 - Split the Data into Train/Test Sets](#4-2)
    - [4.3 - Forward Propagation](#4-3)
        - [Exercise 2 - convolutional_model](#ex-2)
    - [4.4 - Train the Model](#4-4)
- [5 - History Object](#5)
- [6 - Bibliography](#6)

<a name='1'></a>
## 1 - Packages

As usual, begin by loading in the packages.


```python
### v1.1
```


```python
import math
import numpy as np
import h5py
import matplotlib.pyplot as plt
from matplotlib.pyplot import imread
import scipy
from PIL import Image
import pandas as pd
import tensorflow as tf
import tensorflow.keras.layers as tfl
from tensorflow.python.framework import ops
from cnn_utils import *
from test_utils import summary, comparator

%matplotlib inline
np.random.seed(1)
```

<a name='1-1'></a>
### 1.1 - Load the Data and Split the Data into Train/Test Sets

You'll be using the Happy House dataset for this part of the assignment, which contains images of peoples' faces. Your task will be to build a ConvNet that determines whether the people in the images are smiling or not -- because they only get to enter the house if they're smiling!  


```python
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_happy_dataset()

# Normalize image vectors
X_train = X_train_orig/255.
X_test = X_test_orig/255.

# Reshape
Y_train = Y_train_orig.T
Y_test = Y_test_orig.T

print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 600
    number of test examples = 150
    X_train shape: (600, 64, 64, 3)
    Y_train shape: (600, 1)
    X_test shape: (150, 64, 64, 3)
    Y_test shape: (150, 1)


You can display the images contained in the dataset. Images are **64x64** pixels in RGB format (3 channels).


```python
index = 124
plt.imshow(X_train_orig[index]) #display sample training image
plt.show()
```


![png](output_8_0.png)


<a name='2'></a>
## 2 - Layers in TF Keras 

In the previous assignment, you created layers manually in numpy. In TF Keras, you don't have to write code directly to create layers. Rather, TF Keras has pre-defined layers you can use. 

When you create a layer in TF Keras, you are creating a function that takes some input and transforms it into an output you can reuse later. Nice and easy! 

<a name='3'></a>
## 3 - The Sequential API

In the previous assignment, you built helper functions using `numpy` to understand the mechanics behind convolutional neural networks. Most practical applications of deep learning today are built using programming frameworks, which have many built-in functions you can simply call. Keras is a high-level abstraction built on top of TensorFlow, which allows for even more simplified and optimized model creation and training. 

For the first part of this assignment, you'll create a model using TF Keras' Sequential API, which allows you to build layer by layer, and is ideal for building models where each layer has **exactly one** input tensor and **one** output tensor. 

As you'll see, using the Sequential API is simple and straightforward, but is only appropriate for simpler, more straightforward tasks. Later in this notebook you'll spend some time building with a more flexible, powerful alternative: the Functional API. 
 

<a name='3-1'></a>
### 3.1 - Create the Sequential Model

As mentioned earlier, the TensorFlow Keras Sequential API can be used to build simple models with layer operations that proceed in a sequential order. 

You can also add layers incrementally to a Sequential model with the `.add()` method, or remove them using the `.pop()` method, much like you would in a regular Python list.

Actually, you can think of a Sequential model as behaving like a list of layers. Like Python lists, Sequential layers are ordered, and the order in which they are specified matters.  If your model is non-linear or contains layers with multiple inputs or outputs, a Sequential model wouldn't be the right choice!

For any layer construction in Keras, you'll need to specify the input shape in advance. This is because in Keras, the shape of the weights is based on the shape of the inputs. The weights are only created when the model first sees some input data. Sequential models can be created by passing a list of layers to the Sequential constructor, like you will do in the next assignment.

<a name='ex-1'></a>
### Exercise 1 - happyModel

Implement the `happyModel` function below to build the following model: `ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Take help from [tf.keras.layers](https://www.tensorflow.org/api_docs/python/tf/keras/layers) 

Also, plug in the following parameters for all the steps:

 - [ZeroPadding2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ZeroPadding2D): padding 3, input shape 64 x 64 x 3
 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 32 7x7 filters, stride 1
 - [BatchNormalization](https://www.tensorflow.org/api_docs/python/tf/keras/layers/BatchNormalization): for axis 3
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Using default parameters
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 1 neuron and a sigmoid activation. 
 
 
 **Hint:**
 
 Use **tfl** as shorthand for **tensorflow.keras.layers**


```python
# GRADED FUNCTION: happyModel

def happyModel():
    """
    Implements the forward propagation for the binary classification model:
    ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    """
    model = tf.keras.Sequential([
        # ZeroPadding2D with padding 3, input shape of 64 x 64 x 3
        tf.keras.layers.ZeroPadding2D(padding=(3, 3), input_shape=(64, 64, 3)),

        # Conv2D with 32 7x7 filters and stride of 1
        tf.keras.layers.Conv2D(32, (7, 7), strides=(1, 1), padding='valid'),

        # BatchNormalization for the channel axis (channels_last)
        tf.keras.layers.BatchNormalization(axis=-1),

        # ReLU
        tf.keras.layers.ReLU(),

        # Max Pooling 2D with default parameters (pool_size=(2,2))
        tf.keras.layers.MaxPool2D(),

        # Flatten
        tf.keras.layers.Flatten(),

        # Dense layer with 1 unit for output & 'sigmoid' activation
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])

    return model
```


```python
happy_model = happyModel()
# Print a summary for each layer
for layer in summary(happy_model):
    print(layer)
    
output = [['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))],
            ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform'],
            ['BatchNormalization', (None, 64, 64, 32), 128],
            ['ReLU', (None, 64, 64, 32), 0],
            ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid'],
            ['Flatten', (None, 32768), 0],
            ['Dense', (None, 1), 32769, 'sigmoid']]
    
comparator(summary(happy_model), output)
```

    ['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))]
    ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform']
    ['BatchNormalization', (None, 64, 64, 32), 128]
    ['ReLU', (None, 64, 64, 32), 0]
    ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid']
    ['Flatten', (None, 32768), 0]
    ['Dense', (None, 1), 32769, 'sigmoid']
    [32mAll tests passed![0m


#### Expected Output:

```
['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))]
['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform']
['BatchNormalization', (None, 64, 64, 32), 128]
['ReLU', (None, 64, 64, 32), 0]
['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid']
['Flatten', (None, 32768), 0]
['Dense', (None, 1), 32769, 'sigmoid']
All tests passed!
```

Now that your model is created, you can compile it for training with an optimizer and loss of your choice. When the string `accuracy` is specified as a metric, the type of accuracy used will be automatically converted based on the loss function used. This is one of the many optimizations built into TensorFlow that make your life easier! If you'd like to read more on how the compiler operates, check the docs [here](https://www.tensorflow.org/api_docs/python/tf/keras/Model#compile).


```python
happy_model.compile(optimizer='adam',
                   loss='binary_crossentropy',
                   metrics=['accuracy'])
```

It's time to check your model's parameters with the `.summary()` method. This will display the types of layers you have, the shape of the outputs, and how many parameters are in each layer. 


```python
happy_model.summary()
```

    Model: "sequential_1"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    zero_padding2d_1 (ZeroPaddin (None, 70, 70, 3)         0         
    _________________________________________________________________
    conv2d_1 (Conv2D)            (None, 64, 64, 32)        4736      
    _________________________________________________________________
    batch_normalization_1 (Batch (None, 64, 64, 32)        128       
    _________________________________________________________________
    re_lu (ReLU)                 (None, 64, 64, 32)        0         
    _________________________________________________________________
    max_pooling2d_1 (MaxPooling2 (None, 32, 32, 32)        0         
    _________________________________________________________________
    flatten_1 (Flatten)          (None, 32768)             0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 1)                 32769     
    =================================================================
    Total params: 37,633
    Trainable params: 37,569
    Non-trainable params: 64
    _________________________________________________________________


<a name='3-2'></a>
### 3.2 - Train and Evaluate the Model

After creating the model, compiling it with your choice of optimizer and loss function, and doing a sanity check on its contents, you are now ready to build! 

Simply call `.fit()` to train. That's it! No need for mini-batching, saving, or complex backpropagation computations. That's all been done for you, as you're using a TensorFlow dataset with the batches specified already. You do have the option to specify epoch number or minibatch size if you like (for example, in the case of an un-batched dataset).


```python
happy_model.fit(X_train, Y_train, epochs=10, batch_size=16)
```

    Epoch 1/10
    38/38 [==============================] - 4s 103ms/step - loss: 1.1694 - accuracy: 0.7383
    Epoch 2/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.2423 - accuracy: 0.8850
    Epoch 3/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1684 - accuracy: 0.9383
    Epoch 4/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1290 - accuracy: 0.9467
    Epoch 5/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1898 - accuracy: 0.9133
    Epoch 6/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1630 - accuracy: 0.9433
    Epoch 7/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1905 - accuracy: 0.9283
    Epoch 8/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1016 - accuracy: 0.9600
    Epoch 9/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.0951 - accuracy: 0.9717
    Epoch 10/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0531 - accuracy: 0.9817





    <tensorflow.python.keras.callbacks.History at 0x71132f971090>



After that completes, just use `.evaluate()` to evaluate against your test set. This function will print the value of the loss function and the performance metrics specified during the compilation of the model. In this case, the `binary_crossentropy` and the `accuracy` respectively.


```python
happy_model.evaluate(X_test, Y_test)
```

    5/5 [==============================] - 0s 24ms/step - loss: 0.1142 - accuracy: 0.9667





    [0.11422326415777206, 0.9666666388511658]



Easy, right? But what if you need to build a model with shared layers, branches, or multiple inputs and outputs? This is where Sequential, with its beautifully simple yet limited functionality, won't be able to help you. 

Next up: Enter the Functional API, your slightly more complex, highly flexible friend.  

<a name='4'></a>
## 4 - The Functional API

Welcome to the second half of the assignment, where you'll use Keras' flexible [Functional API](https://www.tensorflow.org/guide/keras/functional) to build a ConvNet that can differentiate between 6 sign language digits. 

The Functional API can handle models with non-linear topology, shared layers, as well as layers with multiple inputs or outputs. Imagine that, where the Sequential API requires the model to move in a linear fashion through its layers, the Functional API allows much more flexibility. Where Sequential is a straight line, a Functional model is a graph, where the nodes of the layers can connect in many more ways than one. 

In the visual example below, the one possible direction of the movement Sequential model is shown in contrast to a skip connection, which is just one of the many ways a Functional model can be constructed. A skip connection, as you might have guessed, skips some layer in the network and feeds the output to a later layer in the network. Don't worry, you'll be spending more time with skip connections very soon! 

<img src="images/seq_vs_func.png" style="width:350px;height:200px;">

<a name='4-1'></a>
### 4.1 - Load the SIGNS Dataset

As a reminder, the SIGNS dataset is a collection of 6 signs representing numbers from 0 to 5.


```python
# Loading the data (signs)
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_signs_dataset()
```

<img src="images/SIGNS.png" style="width:800px;height:300px;">

The next cell will show you an example of a labelled image in the dataset. Feel free to change the value of `index` below and re-run to see different examples. 


```python
# Example of an image from the dataset
index = 9
plt.imshow(X_train_orig[index])
print ("y = " + str(np.squeeze(Y_train_orig[:, index])))
```

    y = 4



![png](output_30_1.png)


<a name='4-2'></a>
### 4.2 - Split the Data into Train/Test Sets

In Course 2, you built a fully-connected network for this dataset. But since this is an image dataset, it is more natural to apply a ConvNet to it.

To get started, let's examine the shapes of your data. 


```python
X_train = X_train_orig/255.
X_test = X_test_orig/255.
Y_train = convert_to_one_hot(Y_train_orig, 6).T
Y_test = convert_to_one_hot(Y_test_orig, 6).T
print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 1080
    number of test examples = 120
    X_train shape: (1080, 64, 64, 3)
    Y_train shape: (1080, 6)
    X_test shape: (120, 64, 64, 3)
    Y_test shape: (120, 6)


<a name='4-3'></a>
### 4.3 - Forward Propagation

In TensorFlow, there are built-in functions that implement the convolution steps for you. By now, you should be familiar with how TensorFlow builds computational graphs. In the [Functional API](https://www.tensorflow.org/guide/keras/functional), you create a graph of layers. This is what allows such great flexibility.

However, the following model could also be defined using the Sequential API since the information flow is on a single line. But don't deviate. What we want you to learn is to use the functional API.

Begin building your graph of layers by creating an input node that functions as a callable object:

- **input_img = tf.keras.Input(shape=input_shape):** 

Then, create a new node in the graph of layers by calling a layer on the `input_img` object: 

- **tf.keras.layers.Conv2D(filters= ... , kernel_size= ... , padding='same')(input_img):** Read the full documentation on [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D).

- **tf.keras.layers.MaxPool2D(pool_size=(f, f), strides=(s, s), padding='same'):** `MaxPool2D()` downsamples your input using a window of size (f, f) and strides of size (s, s) to carry out max pooling over each window.  For max pooling, you usually operate on a single example at a time and a single channel at a time. Read the full documentation on [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D).

- **tf.keras.layers.ReLU():** computes the elementwise ReLU of Z (which can be any shape). You can read the full documentation on [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU).

- **tf.keras.layers.Flatten()**: given a tensor "P", this function takes each training (or test) example in the batch and flattens it into a 1D vector.  

    * If a tensor P has the shape (batch_size,h,w,c), it returns a flattened tensor with shape (batch_size, k), where $k=h \times w \times c$.  "k" equals the product of all the dimension sizes other than the first dimension.
    
    * For example, given a tensor with dimensions [100, 2, 3, 4], it flattens the tensor to be of shape [100, 24], where 24 = 2 * 3 * 4.  You can read the full documentation on [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten).

- **tf.keras.layers.Dense(units= ... , activation='softmax')(F):** given the flattened input F, it returns the output computed using a fully connected layer. You can read the full documentation on [Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense).

In the last function above (`tf.keras.layers.Dense()`), the fully connected layer automatically initializes weights in the graph and keeps on training them as you train the model. Hence, you did not need to initialize those weights when initializing the parameters.

Lastly, before creating the model, you'll need to define the output using the last of the function's compositions (in this example, a Dense layer): 

- **outputs = tf.keras.layers.Dense(units=6, activation='softmax')(F)**


#### Window, kernel, filter, pool

The words "kernel" and "filter" are used to refer to the same thing. The word "filter" accounts for the amount of "kernels" that will be used in a single convolution layer. "Pool" is the name of the operation that takes the max or average value of the kernels. 

This is why the parameter `pool_size` refers to `kernel_size`, and you use `(f,f)` to refer to the filter size. 

Pool size and kernel size refer to the same thing in different objects - They refer to the shape of the window where the operation takes place. 

<a name='ex-2'></a>
### Exercise 2 - convolutional_model

Implement the `convolutional_model` function below to build the following model: `CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Use the functions above! 

Also, plug in the following parameters for all the steps:

 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 8 4 by 4 filters, stride 1, padding is "SAME"
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Use an 8 by 8 filter size and an 8 by 8 stride, padding is "SAME"
 - **Conv2D**: Use 16 2 by 2 filters, stride 1, padding is "SAME"
 - **ReLU**
 - **MaxPool2D**: Use a 4 by 4 filter size and a 4 by 4 stride, padding is "SAME"
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 6 neurons and a softmax activation. 


```python
# GRADED FUNCTION: convolutional_model

def convolutional_model(input_shape):
    """
    Implements the forward propagation for the model:
    CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    
    Note that for simplicity and grading purposes, you'll hard-code some values
    such as the stride and kernel (filter) sizes. 
    Normally, functions should take these values as function parameters.
    
    Arguments:
    input_img -- input dataset, of shape (input_shape)

    Returns:
    model -- TF Keras model (object containing the information for the entire training process) 
    """

    input_img = tf.keras.Input(shape=input_shape)
    ## CONV2D: 8 filters 4x4, stride of 1, padding 'SAME'
    Z1 = tf.keras.layers.Conv2D(8,(4,4),strides=(1, 1),padding='same')(input_img)
    
    # Z1 = None
    ## RELU
    # A1 = None
    
    A1 = tf.keras.layers.ReLU()(Z1)
    ## MAXPOOL: window 8x8, stride 8, padding 'SAME'
    # P1 = None
    P1 = tf.keras.layers.MaxPool2D(pool_size=(8, 8),strides=(8,8),padding='same')(A1)
    
    
    ## CONV2D: 16 filters 2x2, stride 1, padding 'SAME'
    # Z2 = None
    
    Z2 =  Z1 = tf.keras.layers.Conv2D(16,(2,2),strides=(1, 1),padding='same')(P1)
    ## RELU
    # A2 = None
    
    A2 = A1 = tf.keras.layers.ReLU()(Z2)
    ## MAXPOOL: window 4x4, stride 4, padding 'SAME'
    # P2 = None
    
    P1 = tf.keras.layers.MaxPool2D(pool_size=(4, 4),strides=(4,4),padding='same')(A2)
    
    ## FLATTEN
    # F = None
    F = tf.keras.layers.Flatten()(P1)
    
    ## Dense layer
    ## 6 neurons in output layer. Hint: one of the arguments should be "activation='softmax'" 
    # outputs = None
    # YOUR CODE STARTS HERE
    
    outputs = tf.keras.layers.Dense(6,activation='softmax')(F)
    
    
    # YOUR CODE ENDS HERE
    model = tf.keras.Model(inputs=input_img, outputs=outputs)
    return model
```


```python
conv_model = convolutional_model((64, 64, 3))
conv_model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
conv_model.summary()
    
output = [['InputLayer', [(None, 64, 64, 3)], 0],
        ['Conv2D', (None, 64, 64, 8), 392, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 64, 64, 8), 0],
        ['MaxPooling2D', (None, 8, 8, 8), 0, (8, 8), (8, 8), 'same'],
        ['Conv2D', (None, 8, 8, 16), 528, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 8, 8, 16), 0],
        ['MaxPooling2D', (None, 2, 2, 16), 0, (4, 4), (4, 4), 'same'],
        ['Flatten', (None, 64), 0],
        ['Dense', (None, 6), 390, 'softmax']]
    
comparator(summary(conv_model), output)
```

    Model: "functional_3"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    input_3 (InputLayer)         [(None, 64, 64, 3)]       0         
    _________________________________________________________________
    conv2d_6 (Conv2D)            (None, 64, 64, 8)         392       
    _________________________________________________________________
    re_lu_5 (ReLU)               (None, 64, 64, 8)         0         
    _________________________________________________________________
    max_pooling2d_6 (MaxPooling2 (None, 8, 8, 8)           0         
    _________________________________________________________________
    conv2d_7 (Conv2D)            (None, 8, 8, 16)          528       
    _________________________________________________________________
    re_lu_6 (ReLU)               (None, 8, 8, 16)          0         
    _________________________________________________________________
    max_pooling2d_7 (MaxPooling2 (None, 2, 2, 16)          0         
    _________________________________________________________________
    flatten_4 (Flatten)          (None, 64)                0         
    _________________________________________________________________
    dense_4 (Dense)              (None, 6)                 390       
    =================================================================
    Total params: 1,310
    Trainable params: 1,310
    Non-trainable params: 0
    _________________________________________________________________
    [32mAll tests passed![0m


Both the Sequential and Functional APIs return a TF Keras model object. The only difference is how inputs are handled inside the object model! 

<a name='4-4'></a>
### 4.4 - Train the Model


```python
train_dataset = tf.data.Dataset.from_tensor_slices((X_train, Y_train)).batch(64)
test_dataset = tf.data.Dataset.from_tensor_slices((X_test, Y_test)).batch(64)
history = conv_model.fit(train_dataset, epochs=100, validation_data=test_dataset)
```

    Epoch 1/100
    17/17 [==============================] - 2s 112ms/step - loss: 1.8195 - accuracy: 0.1769 - val_loss: 1.7917 - val_accuracy: 0.1667
    Epoch 2/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7918 - accuracy: 0.1630 - val_loss: 1.7874 - val_accuracy: 0.2500
    Epoch 3/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7874 - accuracy: 0.2102 - val_loss: 1.7828 - val_accuracy: 0.3083
    Epoch 4/100
    17/17 [==============================] - 2s 101ms/step - loss: 1.7831 - accuracy: 0.2259 - val_loss: 1.7782 - val_accuracy: 0.2917
    Epoch 5/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7784 - accuracy: 0.2796 - val_loss: 1.7735 - val_accuracy: 0.2667
    Epoch 6/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7734 - accuracy: 0.2870 - val_loss: 1.7678 - val_accuracy: 0.2583
    Epoch 7/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7675 - accuracy: 0.3231 - val_loss: 1.7596 - val_accuracy: 0.3417
    Epoch 8/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.7580 - accuracy: 0.3157 - val_loss: 1.7476 - val_accuracy: 0.3083
    Epoch 9/100
    17/17 [==============================] - 2s 112ms/step - loss: 1.7460 - accuracy: 0.3204 - val_loss: 1.7331 - val_accuracy: 0.3167
    Epoch 10/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7308 - accuracy: 0.3426 - val_loss: 1.7144 - val_accuracy: 0.3417
    Epoch 11/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7115 - accuracy: 0.3713 - val_loss: 1.6950 - val_accuracy: 0.3333
    Epoch 12/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6892 - accuracy: 0.3889 - val_loss: 1.6693 - val_accuracy: 0.4000
    Epoch 13/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6626 - accuracy: 0.4120 - val_loss: 1.6395 - val_accuracy: 0.4333
    Epoch 14/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6323 - accuracy: 0.4352 - val_loss: 1.6040 - val_accuracy: 0.4333
    Epoch 15/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.5992 - accuracy: 0.4556 - val_loss: 1.5700 - val_accuracy: 0.4500
    Epoch 16/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.5635 - accuracy: 0.4750 - val_loss: 1.5308 - val_accuracy: 0.4667
    Epoch 17/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.5263 - accuracy: 0.4898 - val_loss: 1.4936 - val_accuracy: 0.4667
    Epoch 18/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.4868 - accuracy: 0.5093 - val_loss: 1.4517 - val_accuracy: 0.4833
    Epoch 19/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.4470 - accuracy: 0.5250 - val_loss: 1.4110 - val_accuracy: 0.5000
    Epoch 20/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.4076 - accuracy: 0.5296 - val_loss: 1.3716 - val_accuracy: 0.5083
    Epoch 21/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.3677 - accuracy: 0.5472 - val_loss: 1.3325 - val_accuracy: 0.5583
    Epoch 22/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.3282 - accuracy: 0.5630 - val_loss: 1.2929 - val_accuracy: 0.5667
    Epoch 23/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.2902 - accuracy: 0.5722 - val_loss: 1.2550 - val_accuracy: 0.5833
    Epoch 24/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.2532 - accuracy: 0.5843 - val_loss: 1.2179 - val_accuracy: 0.6083
    Epoch 25/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.2181 - accuracy: 0.5981 - val_loss: 1.1830 - val_accuracy: 0.6250
    Epoch 26/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1835 - accuracy: 0.6130 - val_loss: 1.1490 - val_accuracy: 0.6417
    Epoch 27/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.1499 - accuracy: 0.6231 - val_loss: 1.1159 - val_accuracy: 0.6500
    Epoch 28/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.1177 - accuracy: 0.6370 - val_loss: 1.0848 - val_accuracy: 0.6667
    Epoch 29/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.0866 - accuracy: 0.6546 - val_loss: 1.0548 - val_accuracy: 0.6750
    Epoch 30/100
    17/17 [==============================] - 2s 101ms/step - loss: 1.0569 - accuracy: 0.6667 - val_loss: 1.0264 - val_accuracy: 0.7000
    Epoch 31/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.0282 - accuracy: 0.6778 - val_loss: 0.9998 - val_accuracy: 0.7083
    Epoch 32/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.0013 - accuracy: 0.6889 - val_loss: 0.9744 - val_accuracy: 0.7250
    Epoch 33/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9759 - accuracy: 0.6935 - val_loss: 0.9507 - val_accuracy: 0.7250
    Epoch 34/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.9517 - accuracy: 0.7093 - val_loss: 0.9284 - val_accuracy: 0.7417
    Epoch 35/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.9287 - accuracy: 0.7185 - val_loss: 0.9080 - val_accuracy: 0.7333
    Epoch 36/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.9073 - accuracy: 0.7231 - val_loss: 0.8873 - val_accuracy: 0.7417
    Epoch 37/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.8870 - accuracy: 0.7287 - val_loss: 0.8687 - val_accuracy: 0.7667
    Epoch 38/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.8675 - accuracy: 0.7398 - val_loss: 0.8525 - val_accuracy: 0.7667
    Epoch 39/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.8495 - accuracy: 0.7472 - val_loss: 0.8357 - val_accuracy: 0.7750
    Epoch 40/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.8321 - accuracy: 0.7519 - val_loss: 0.8206 - val_accuracy: 0.7667
    Epoch 41/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.8159 - accuracy: 0.7574 - val_loss: 0.8058 - val_accuracy: 0.7750
    Epoch 42/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.8000 - accuracy: 0.7630 - val_loss: 0.7917 - val_accuracy: 0.7750
    Epoch 43/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7851 - accuracy: 0.7685 - val_loss: 0.7789 - val_accuracy: 0.7750
    Epoch 44/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7710 - accuracy: 0.7676 - val_loss: 0.7667 - val_accuracy: 0.7833
    Epoch 45/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.7573 - accuracy: 0.7713 - val_loss: 0.7552 - val_accuracy: 0.7833
    Epoch 46/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.7444 - accuracy: 0.7796 - val_loss: 0.7442 - val_accuracy: 0.7833
    Epoch 47/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.7317 - accuracy: 0.7824 - val_loss: 0.7334 - val_accuracy: 0.8000
    Epoch 48/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7199 - accuracy: 0.7843 - val_loss: 0.7237 - val_accuracy: 0.8000
    Epoch 49/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7087 - accuracy: 0.7926 - val_loss: 0.7140 - val_accuracy: 0.8000
    Epoch 50/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6978 - accuracy: 0.7935 - val_loss: 0.7051 - val_accuracy: 0.8083
    Epoch 51/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.6870 - accuracy: 0.7981 - val_loss: 0.6968 - val_accuracy: 0.7917
    Epoch 52/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6771 - accuracy: 0.7991 - val_loss: 0.6885 - val_accuracy: 0.7833
    Epoch 53/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6673 - accuracy: 0.8028 - val_loss: 0.6803 - val_accuracy: 0.7917
    Epoch 54/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.6580 - accuracy: 0.8046 - val_loss: 0.6732 - val_accuracy: 0.7917
    Epoch 55/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.6489 - accuracy: 0.8028 - val_loss: 0.6652 - val_accuracy: 0.7917
    Epoch 56/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.6402 - accuracy: 0.8056 - val_loss: 0.6589 - val_accuracy: 0.7917
    Epoch 57/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.6320 - accuracy: 0.8083 - val_loss: 0.6520 - val_accuracy: 0.7917
    Epoch 58/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6239 - accuracy: 0.8130 - val_loss: 0.6462 - val_accuracy: 0.7917
    Epoch 59/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6164 - accuracy: 0.8139 - val_loss: 0.6410 - val_accuracy: 0.7833
    Epoch 60/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.6090 - accuracy: 0.8176 - val_loss: 0.6349 - val_accuracy: 0.7833
    Epoch 61/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.6015 - accuracy: 0.8204 - val_loss: 0.6303 - val_accuracy: 0.7917
    Epoch 62/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5943 - accuracy: 0.8204 - val_loss: 0.6253 - val_accuracy: 0.7917
    Epoch 63/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5877 - accuracy: 0.8194 - val_loss: 0.6214 - val_accuracy: 0.7917
    Epoch 64/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.5813 - accuracy: 0.8185 - val_loss: 0.6161 - val_accuracy: 0.7917
    Epoch 65/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.5752 - accuracy: 0.8185 - val_loss: 0.6117 - val_accuracy: 0.8000
    Epoch 66/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5691 - accuracy: 0.8194 - val_loss: 0.6075 - val_accuracy: 0.8000
    Epoch 67/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5633 - accuracy: 0.8204 - val_loss: 0.6031 - val_accuracy: 0.8000
    Epoch 68/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5571 - accuracy: 0.8222 - val_loss: 0.5987 - val_accuracy: 0.8000
    Epoch 69/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5514 - accuracy: 0.8222 - val_loss: 0.5951 - val_accuracy: 0.8000
    Epoch 70/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.5456 - accuracy: 0.8250 - val_loss: 0.5906 - val_accuracy: 0.8000
    Epoch 71/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5402 - accuracy: 0.8287 - val_loss: 0.5872 - val_accuracy: 0.8000
    Epoch 72/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5347 - accuracy: 0.8324 - val_loss: 0.5822 - val_accuracy: 0.8000
    Epoch 73/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5295 - accuracy: 0.8324 - val_loss: 0.5778 - val_accuracy: 0.8000
    Epoch 74/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5244 - accuracy: 0.8352 - val_loss: 0.5760 - val_accuracy: 0.8000
    Epoch 75/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5200 - accuracy: 0.8361 - val_loss: 0.5708 - val_accuracy: 0.8000
    Epoch 76/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5144 - accuracy: 0.8380 - val_loss: 0.5679 - val_accuracy: 0.8000
    Epoch 77/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5100 - accuracy: 0.8380 - val_loss: 0.5643 - val_accuracy: 0.8083
    Epoch 78/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5054 - accuracy: 0.8389 - val_loss: 0.5613 - val_accuracy: 0.8000
    Epoch 79/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5009 - accuracy: 0.8407 - val_loss: 0.5585 - val_accuracy: 0.8000
    Epoch 80/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4969 - accuracy: 0.8417 - val_loss: 0.5549 - val_accuracy: 0.8000
    Epoch 81/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4925 - accuracy: 0.8407 - val_loss: 0.5521 - val_accuracy: 0.8000
    Epoch 82/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4881 - accuracy: 0.8444 - val_loss: 0.5493 - val_accuracy: 0.8000
    Epoch 83/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4843 - accuracy: 0.8435 - val_loss: 0.5460 - val_accuracy: 0.8083
    Epoch 84/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4799 - accuracy: 0.8454 - val_loss: 0.5436 - val_accuracy: 0.8083
    Epoch 85/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.4761 - accuracy: 0.8472 - val_loss: 0.5395 - val_accuracy: 0.8083
    Epoch 86/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4718 - accuracy: 0.8463 - val_loss: 0.5374 - val_accuracy: 0.8083
    Epoch 87/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4681 - accuracy: 0.8481 - val_loss: 0.5332 - val_accuracy: 0.8083
    Epoch 88/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4643 - accuracy: 0.8481 - val_loss: 0.5301 - val_accuracy: 0.8083
    Epoch 89/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4601 - accuracy: 0.8509 - val_loss: 0.5271 - val_accuracy: 0.7917
    Epoch 90/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4562 - accuracy: 0.8556 - val_loss: 0.5242 - val_accuracy: 0.7917
    Epoch 91/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4524 - accuracy: 0.8537 - val_loss: 0.5214 - val_accuracy: 0.7917
    Epoch 92/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4488 - accuracy: 0.8574 - val_loss: 0.5199 - val_accuracy: 0.7917
    Epoch 93/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4458 - accuracy: 0.8593 - val_loss: 0.5163 - val_accuracy: 0.8083
    Epoch 94/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4417 - accuracy: 0.8611 - val_loss: 0.5153 - val_accuracy: 0.7917
    Epoch 95/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4387 - accuracy: 0.8611 - val_loss: 0.5122 - val_accuracy: 0.8000
    Epoch 96/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.4358 - accuracy: 0.8630 - val_loss: 0.5094 - val_accuracy: 0.8000
    Epoch 97/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4321 - accuracy: 0.8639 - val_loss: 0.5057 - val_accuracy: 0.8000
    Epoch 98/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4286 - accuracy: 0.8667 - val_loss: 0.5025 - val_accuracy: 0.8000
    Epoch 99/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.4253 - accuracy: 0.8667 - val_loss: 0.4997 - val_accuracy: 0.8083
    Epoch 100/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4219 - accuracy: 0.8685 - val_loss: 0.4978 - val_accuracy: 0.8083


<a name='5'></a>
## 5 - History Object 

The history object is an output of the `.fit()` operation, and provides a record of all the loss and metric values in memory. It's stored as a dictionary that you can retrieve at `history.history`: 


```python
history.history
```




    {'loss': [1.819482445716858,
      1.791803240776062,
      1.7874102592468262,
      1.7831279039382935,
      1.7783628702163696,
      1.7734472751617432,
      1.767494797706604,
      1.7580314874649048,
      1.7459630966186523,
      1.7308471202850342,
      1.7114660739898682,
      1.689164161682129,
      1.6625844240188599,
      1.6322659254074097,
      1.5992457866668701,
      1.563462257385254,
      1.52634859085083,
      1.4867643117904663,
      1.4470032453536987,
      1.4075992107391357,
      1.3676997423171997,
      1.3282206058502197,
      1.2902380228042603,
      1.2531976699829102,
      1.2180513143539429,
      1.1835170984268188,
      1.1498987674713135,
      1.1177265644073486,
      1.0866477489471436,
      1.0568909645080566,
      1.0282350778579712,
      1.0012750625610352,
      0.9759495258331299,
      0.9516597986221313,
      0.928672194480896,
      0.9072985053062439,
      0.8870434761047363,
      0.8674741387367249,
      0.849457323551178,
      0.8320804238319397,
      0.8158570528030396,
      0.8000369071960449,
      0.7851008772850037,
      0.7709523439407349,
      0.7573375701904297,
      0.7444352507591248,
      0.7316558957099915,
      0.7198522686958313,
      0.7087320685386658,
      0.697847843170166,
      0.6870427131652832,
      0.6770551204681396,
      0.6673287749290466,
      0.6579511165618896,
      0.648931622505188,
      0.6402403712272644,
      0.6320099830627441,
      0.6238804459571838,
      0.6164481043815613,
      0.608989953994751,
      0.6014789342880249,
      0.5942516326904297,
      0.5876649022102356,
      0.5813104510307312,
      0.5751693844795227,
      0.5691431760787964,
      0.5632504224777222,
      0.5570679903030396,
      0.5513905882835388,
      0.5456362962722778,
      0.5401905179023743,
      0.5346503257751465,
      0.5295287370681763,
      0.524359941482544,
      0.5199875235557556,
      0.5143693089485168,
      0.5099881291389465,
      0.5054355263710022,
      0.5009496212005615,
      0.4968635141849518,
      0.49251195788383484,
      0.48807293176651,
      0.4842515289783478,
      0.4798640012741089,
      0.4761067032814026,
      0.4717927575111389,
      0.4681360721588135,
      0.46429765224456787,
      0.4601176083087921,
      0.4562298059463501,
      0.4523782432079315,
      0.4488197863101959,
      0.4458138346672058,
      0.44165557622909546,
      0.43871328234672546,
      0.43582385778427124,
      0.43209171295166016,
      0.4286055564880371,
      0.4253290295600891,
      0.4219016432762146],
     'accuracy': [0.17685185372829437,
      0.16296295821666718,
      0.2101851850748062,
      0.22592592239379883,
      0.2796296179294586,
      0.28703704476356506,
      0.3231481611728668,
      0.3157407343387604,
      0.3203703761100769,
      0.34259259700775146,
      0.3712962865829468,
      0.3888888955116272,
      0.41203704476356506,
      0.43518519401550293,
      0.4555555582046509,
      0.4749999940395355,
      0.489814817905426,
      0.5092592835426331,
      0.5249999761581421,
      0.529629647731781,
      0.5472221970558167,
      0.5629629492759705,
      0.5722222328186035,
      0.5842592716217041,
      0.5981481671333313,
      0.6129629611968994,
      0.6231481432914734,
      0.6370370388031006,
      0.654629647731781,
      0.6666666865348816,
      0.6777777671813965,
      0.6888889074325562,
      0.6935185194015503,
      0.7092592716217041,
      0.7185184955596924,
      0.7231481671333313,
      0.7287036776542664,
      0.739814817905426,
      0.7472222447395325,
      0.7518518567085266,
      0.7574074268341064,
      0.7629629373550415,
      0.7685185074806213,
      0.7675926089286804,
      0.7712963223457336,
      0.779629647731781,
      0.7824074029922485,
      0.7842592597007751,
      0.7925925850868225,
      0.7935185432434082,
      0.7981481552124023,
      0.7990740537643433,
      0.8027777671813965,
      0.8046296238899231,
      0.8027777671813965,
      0.8055555820465088,
      0.8083333373069763,
      0.8129629492759705,
      0.8138889074325562,
      0.8175926208496094,
      0.8203703761100769,
      0.8203703761100769,
      0.8194444179534912,
      0.8185185194015503,
      0.8185185194015503,
      0.8194444179534912,
      0.8203703761100769,
      0.8222222328186035,
      0.8222222328186035,
      0.824999988079071,
      0.8287037014961243,
      0.8324074149131775,
      0.8324074149131775,
      0.835185170173645,
      0.8361111283302307,
      0.8379629850387573,
      0.8379629850387573,
      0.8388888835906982,
      0.8407407402992249,
      0.8416666388511658,
      0.8407407402992249,
      0.8444444537162781,
      0.8435184955596924,
      0.845370352268219,
      0.8472222089767456,
      0.8462963104248047,
      0.8481481671333313,
      0.8481481671333313,
      0.8509259223937988,
      0.855555534362793,
      0.8537036776542664,
      0.8574073910713196,
      0.8592592477798462,
      0.8611111044883728,
      0.8611111044883728,
      0.8629629611968994,
      0.8638888597488403,
      0.8666666746139526,
      0.8666666746139526,
      0.8685185313224792],
     'val_loss': [1.7916702032089233,
      1.7874457836151123,
      1.7828242778778076,
      1.778213381767273,
      1.7735041379928589,
      1.7677536010742188,
      1.7595568895339966,
      1.7475659847259521,
      1.7330867052078247,
      1.7144371271133423,
      1.695023775100708,
      1.669305682182312,
      1.6394718885421753,
      1.6040377616882324,
      1.570048451423645,
      1.5308161973953247,
      1.4935517311096191,
      1.4517252445220947,
      1.411035418510437,
      1.3716014623641968,
      1.3324501514434814,
      1.29289972782135,
      1.255035400390625,
      1.2178642749786377,
      1.1830259561538696,
      1.1490299701690674,
      1.1159284114837646,
      1.084782361984253,
      1.0548393726348877,
      1.0263506174087524,
      0.9997664093971252,
      0.9743788838386536,
      0.9507462382316589,
      0.9284378290176392,
      0.9080188274383545,
      0.8872874975204468,
      0.8687047362327576,
      0.8525418639183044,
      0.8356907963752747,
      0.8205800652503967,
      0.8058025240898132,
      0.7916942834854126,
      0.7789368033409119,
      0.7666871547698975,
      0.7552471160888672,
      0.7441591620445251,
      0.7334209680557251,
      0.7236955761909485,
      0.714047372341156,
      0.7051425576210022,
      0.6967732906341553,
      0.6885297894477844,
      0.6802833676338196,
      0.6731954216957092,
      0.6652341485023499,
      0.6589411497116089,
      0.6519820094108582,
      0.6462337970733643,
      0.6409766674041748,
      0.6349065899848938,
      0.6303399205207825,
      0.6252895593643188,
      0.6213707327842712,
      0.6161370873451233,
      0.611709475517273,
      0.6074755787849426,
      0.6030510067939758,
      0.5986663699150085,
      0.5951386094093323,
      0.5906404852867126,
      0.5872113704681396,
      0.5821697115898132,
      0.5778495073318481,
      0.5760135650634766,
      0.5708335638046265,
      0.5679111480712891,
      0.5643146634101868,
      0.5612878203392029,
      0.5584554672241211,
      0.5549470782279968,
      0.5520648956298828,
      0.5492655634880066,
      0.5459606051445007,
      0.5435916185379028,
      0.5395150780677795,
      0.5373754501342773,
      0.533160924911499,
      0.5300582051277161,
      0.5270883440971375,
      0.5242087244987488,
      0.5214154720306396,
      0.5199404954910278,
      0.5163059234619141,
      0.5152847766876221,
      0.5122215151786804,
      0.5094016790390015,
      0.5056703090667725,
      0.5025275945663452,
      0.4996720552444458,
      0.49777188897132874],
     'val_accuracy': [0.1666666716337204,
      0.25,
      0.3083333373069763,
      0.2916666567325592,
      0.2666666805744171,
      0.25833332538604736,
      0.34166666865348816,
      0.3083333373069763,
      0.3166666626930237,
      0.34166666865348816,
      0.3333333432674408,
      0.4000000059604645,
      0.4333333373069763,
      0.4333333373069763,
      0.44999998807907104,
      0.46666666865348816,
      0.46666666865348816,
      0.4833333194255829,
      0.5,
      0.5083333253860474,
      0.5583333373069763,
      0.5666666626930237,
      0.5833333134651184,
      0.6083333492279053,
      0.625,
      0.6416666507720947,
      0.6499999761581421,
      0.6666666865348816,
      0.675000011920929,
      0.699999988079071,
      0.7083333134651184,
      0.7250000238418579,
      0.7250000238418579,
      0.7416666746139526,
      0.7333333492279053,
      0.7416666746139526,
      0.7666666507720947,
      0.7666666507720947,
      0.7749999761581421,
      0.7666666507720947,
      0.7749999761581421,
      0.7749999761581421,
      0.7749999761581421,
      0.7833333611488342,
      0.7833333611488342,
      0.7833333611488342,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.8083333373069763,
      0.7916666865348816,
      0.7833333611488342,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7833333611488342,
      0.7833333611488342,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.8083333373069763,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.8083333373069763,
      0.7916666865348816,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763]}



Now visualize the loss over time using `history.history`: 


```python
# The history.history["loss"] entry is a dictionary with as many values as epochs that the
# model was trained on. 
df_loss_acc = pd.DataFrame(history.history)
df_loss= df_loss_acc[['loss','val_loss']]
df_loss.rename(columns={'loss':'train','val_loss':'validation'},inplace=True)
df_acc= df_loss_acc[['accuracy','val_accuracy']]
df_acc.rename(columns={'accuracy':'train','val_accuracy':'validation'},inplace=True)
df_loss.plot(title='Model loss',figsize=(12,8)).set(xlabel='Epoch',ylabel='Loss')
df_acc.plot(title='Model Accuracy',figsize=(12,8)).set(xlabel='Epoch',ylabel='Accuracy')
```




    [Text(0, 0.5, 'Accuracy'), Text(0.5, 0, 'Epoch')]




![png](output_43_1.png)



![png](output_43_2.png)


**Congratulations**! You've finished the assignment and built two models: One that recognizes  smiles, and another that recognizes SIGN language with almost 80% accuracy on the test set. In addition to that, you now also understand the applications of two Keras APIs: Sequential and Functional. Nicely done! 

By now, you know a bit about how the Functional API works and may have glimpsed the possibilities. In your next assignment, you'll really get a feel for its power when you get the opportunity to build a very deep ConvNet, using ResNets! 

<a name='6'></a>
## 6 - Bibliography

You're always encouraged to read the official documentation. To that end, you can find the docs for the Sequential and Functional APIs here: 

https://www.tensorflow.org/guide/keras/sequential_model

https://www.tensorflow.org/guide/keras/functional
